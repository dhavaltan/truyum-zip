export interface User{

    userName: string;
    firstName: string;
    lastName: string;
    password: string;
    role: string;
}